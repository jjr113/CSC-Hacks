
public class Folder 
{
    private String name;
    private FolderLinkedList<Folder> folders;

    public Folder() 
    {
        setName("");
        setFolders(new FolderLinkedList<Folder>());
    }
    public Folder(String name) 
    {
        setName(name);
        setFolders(new FolderLinkedList<Folder>());
    }
    public Folder(String name, FolderLinkedList<Folder> f) 
    {
        setName(name);
        setFolders(f);
    }
    
    public String getName(){return name;}
    public FolderLinkedList<Folder> getFolders(){return folders;}
    
    public void setName(String n){name = n;}
    public void setFolders(FolderLinkedList<Folder> f){folders = f;}
    public void addFolder(Folder f){folders.insertAtTail(f);}
    public void removeFolder(Folder f){folders.remove(f);}
    
    @Override
    public String toString()
    {
        return getName() + getFolders();
    }
}
