
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipCreator {

    public static void main(String[] args) throws IOException {
        Scanner console = new Scanner(System.in);
        System.out.println("----------ZipCreator----------");
        System.out.println("If you would like to make a zip file with folders inside of folders, type 2 and press enter\n"
                        + "If you would like to make a zip file with a folder within each folder, type 1 and press enter\n"
                        + "If you would like to create a simple zip file with a folder (optional) and a txt file (inside folder or inside zip), type 0 and press enter\n");
        int choice = console.nextInt();
        if (choice == 0)
        {
            /*
            This will create a simple zip file with a folder (optional) and a txt file (inside folder or inside zip).
            This will also store the zip file where this .java file is located.
            */
            StringBuilder sb = new StringBuilder();
            sb.append("Test String");
            //asks for name of zip
            System.out.print("Enter the name of your .zip file: ");
            String zip = console.next();
            //creates zip file and assigns it to a ZipOutputStream
            File f = new File(zip + ".zip");
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(f));
            //asks for name of txt and if it should be in a folder or not
            System.out.print("\nEnter the name of your .txt file: ");
            String txt = console.next();
            System.out.print("\nWould you like the .txt to be in a folder? [Y][N]: ");
            String fold = console.next();
            //create new zip entry file
            ZipEntry e;
            //tacks on "foldername/textfilename" to front of new zip entry if folder is wanted, if not then add "textfilename" to front
            if (fold.equals("Y"))
            {
                System.out.print("What would you like the folder to be named?: ");
                fold = console.next();
                e = new ZipEntry(fold + "/" + txt + ".txt");
            }
            else
                e = new ZipEntry(txt + ".txt");
            //creates arraylist and calls create zip to add all zip entries to ZipOutputStream
            ArrayList<ZipEntry> arr = new ArrayList<>();
            arr.add(e);
            createZip(out, arr, sb);
            //close outputstream
            out.close();
        }
        else if (choice == 1)
        {
            /*
            This will create a simple zip file with a folder within each folder created
            This will also store the zip file where this .java file is located.
            */
            //asks for name of zip
            System.out.print("\n___________Part2___________\nEnter the name of your .zip file: ");
            String zip1 = console.next();

            File f1 = new File(zip1 + ".zip");
            ZipOutputStream out1 = new ZipOutputStream(new FileOutputStream(f1));

            FolderLinkedList<Folder> folders = new FolderLinkedList<Folder>();
            boolean cont1 = true;
            while (cont1)
            {
                System.out.print("Would you like to add a folder to the zip? \n[if no then type 'done', if yes then type name of folder]\nName = ");
                String folder = console.next();
                if (folder.equals("done"))
                    cont1 = false;
                else
                {
                    folders.insertAtTail(new Folder(folder));
                }
            }
            cont1 = true;
            for (int i = 0; i < folders.size(); ++i)
            {

                System.out.print("Would you like to add a folder to " + folders.get(i).getName() + " folder? \n[if no then type 'done', if yes then type name of folder]\nName = ");
                String folder = console.next();
                if (folder.equals("done"))
                    cont1 = false;
                else
                {
                    folders.get(i).addFolder(new Folder(folder));
                }
            }
            //creates zip file and assigns it to a ZipOutputStream
            Zip z = new Zip(zip1, folders);
            //create new zip entry file
            ZipEntry e1;
            //tacks on "foldername/textfilename" to front of new zip entry if folder is wanted, if not then add "textfilename" to front
            //creates arraylist and calls create zip to add all zip entries to ZipOutputStream
            ArrayList<ZipEntry> arr1 = new ArrayList<>();
            String fold2 = "";
            for (int i = 0; i < z.getFolders().size(); ++i)
            {
                fold2 = z.getFolders().get(i).toString();
                e1 = new ZipEntry(fold2 + "/");
                arr1.add(e1);
            }
            createZip(out1, arr1);
            //close outputstream
            out1.close();
        }
        else
        {
            /*
            This will create a simple zip file with a folders within each folder created
            This will also store the zip file where this .java file is located.
            */
            //asks for name of zip
            System.out.print("\n___________Part3___________\nEnter the name of your .zip file: ");
            String zip2 = console.next();
            //creates zip file and assigns it to a ZipOutputStream
            File f2 = new File(zip2 + ".zip");
            ZipOutputStream out2 = new ZipOutputStream(new FileOutputStream(f2));
            //creates linkedlist to hold the main folders
            FolderLinkedList<Folder> folders2 = new FolderLinkedList<Folder>();
            //creates new zip with main folders
            Zip z2 = new Zip(zip2, folders2);
            //create new zip entry file and arraylist for each folder (each folder added needs a zipentry)
            ZipEntry e2;
            ArrayList<ZipEntry> arr2 = new ArrayList<>();
            //adds main folders, when done user enters "done"
            boolean cont2 = true;
            while (cont2)
            {
                System.out.print("Would you like to add a folder to the zip? \n[if no then type 'done', if yes then type name of folder]\nName = ");
                String folder = console.next();
                if (folder.equals("done"))
                    cont2 = false;
                else
                {
                    z2.getFolders().insertAtTail(new Folder(folder));
                    arr2.add(new ZipEntry(folder + "/"));
                }
            }
            //adds folders inside main folders
            cont2 = true;
            for (int i = 0; i < z2.getFolders().size(); ++i)
            {
                while (cont2)
                {
                    System.out.print("Would you like to add a folder to " + folders2.get(i).getName() + " folder? \n[if no then type 'done', if yes then type name of folder]\nName = ");
                    String folder = console.next();
                    if (folder.equals("done"))
                        cont2 = false;
                    else
                    {
                        folders2.get(i).addFolder(new Folder(folder));
                        arr2.add(new ZipEntry(folders2.get(i).getName() + "/" + folder + "/"));
                    }
                }
                cont2 = true;
            }
            createZip(out2, arr2);
            //close outputstream
            out2.close();
        }
    }
    //creates new zip with all zip entries
    private static void createZip(ZipOutputStream out, ArrayList<ZipEntry> arrL, StringBuilder sb) throws IOException
    {
        for (int i = 0; i < arrL.size(); i++)
            out.putNextEntry(arrL.get(i));
        byte[] data = sb.toString().getBytes();
        out.write(data, 0, data.length);
        out.closeEntry();
    }
    private static void createZip(ZipOutputStream out, ArrayList<ZipEntry> arrL) throws IOException
    {
        for (int i = 0; i < arrL.size(); i++)
            out.putNextEntry(arrL.get(i));
        out.closeEntry();
    }
}
