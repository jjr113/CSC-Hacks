
public class Zip 
{
    private String name;
    private FolderLinkedList<Folder> folders;

    public Zip() 
    {
        setName("");
        folders = new FolderLinkedList<>();
    }
    public Zip(String name, FolderLinkedList<Folder> f) 
    {
        setName(name);
        setFolders(f);
    }
    
    public String getName(){return name;}
    public FolderLinkedList<Folder> getFolders(){return folders;}
    
    public void setName(String n){name = n;}
    public void setFolders(FolderLinkedList<Folder> f){folders = f;}
    public void addFolder(Folder f){folders.insertAtTail(f);}
    public void removeFolder(Folder f){folders.remove(f);}
}
