# SwingInspire
A Java Swing Application made from scratch, please have a look, if you like clone and tweak to suit your needs.

# Screenshots

![alt text](https://github.com/k33ptoo/SwingInspire/blob/master/images/sc.png)
